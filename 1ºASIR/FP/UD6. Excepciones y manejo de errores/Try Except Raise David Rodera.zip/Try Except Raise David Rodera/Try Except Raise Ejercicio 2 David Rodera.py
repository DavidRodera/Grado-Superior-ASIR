def convertir_a_entero():
    entrada_usuario = input("Ingresa varios valores separados por comas (ej: 10, hola, 20, 3.5): ")

    lista_entrada = [item.strip() for item in entrada_usuario.split(",")]

    enteros = []

    for item in lista_entrada:
        try:
            valor = int(item)
            enteros.append(valor)
        except ValueError:
            continue

    print(f"\nLista procesada: {lista_entrada}")
    print(f"Valores que son enteros: {enteros}")

convertir_a_entero()
