try:
    num1 = float(input("Ingresa el primer número: "))
    num2 = float(input("Ingresa el segundo número: "))
    resultado = num1 / num2
    print(f"El resultado es: {resultado}")
except ZeroDivisionError:
    print("Error: No puedes dividir un número entre cero.")
except ValueError:
    print("Error: Debes ingresar valores numéricos, no letras.")
