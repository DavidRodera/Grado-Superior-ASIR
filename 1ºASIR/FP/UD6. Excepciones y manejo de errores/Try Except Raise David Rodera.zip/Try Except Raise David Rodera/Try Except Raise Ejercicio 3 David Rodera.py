colores = ["Rojo", "Azul", "Verde", "Amarillo", "Violeta"]

try:
    indice = int(input("Introduce el índice del color (0-4): "))
    print(f"El color seleccionado es: {colores[indice]}")
except IndexError:
    print("Ups... El índice está fuera de rango. Intenta con un número del 0 al 4.")
except ValueError:
    print("Por favor, introduce un número entero válido.")
