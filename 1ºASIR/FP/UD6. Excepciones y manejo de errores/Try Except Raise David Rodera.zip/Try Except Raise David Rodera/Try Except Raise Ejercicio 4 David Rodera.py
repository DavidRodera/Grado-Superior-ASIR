saldo = 1000

try:
    retiro = input("¿Cuánto dinero deseas retirar?: ")
    monto = float(retiro)

    if monto > saldo:
        raise Exception("Fondos insuficientes.")

    saldo -= monto

except ValueError:
    print("Error: El monto ingresado debe ser un número.")
except Exception as e:
    print(f"Operación fallida: {e}")
else:
    print(f"Retiro exitoso. Tu nuevo saldo es: ${saldo}")
finally:
    print("Gracias por usar nuestro cajero.")
