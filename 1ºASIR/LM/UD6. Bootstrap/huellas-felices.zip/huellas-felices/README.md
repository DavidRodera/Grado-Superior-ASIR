# 🐾 Huellas Felices

Proyecto web para la asignatura **Lenguaje de Marcas** — Fase 2.

**Autor:** David Rodera  
**Descripción:** Plataforma de adopción responsable de mascotas.

## Estructura del proyecto

```
huellas-felices/
├── index.html          ← Página principal
├── css/
│   └── style.css       ← Estilos personalizados (mínimos, Bootstrap-first)
├── js/
│   └── script.js       ← Lógica: filtros, navbar scroll, validación form
└── img/
    ├── hero-luna.webp
    ├── hero-mochi.webp
    ├── hero-nube.webp
    ├── card-luna.webp
    ├── card-mochi.webp
    ├── card-nube.webp
    ├── card-rocky.webp
    ├── card-canela.webp
    ├── card-thor.webp
    └── og-image.webp
```

## Componentes Bootstrap incluidos

| Componente | Uso |
|---|---|
| Navbar | Fija, colapsa en hamburguesa en móvil |
| Carousel | Hero con 3 slides de mascotas |
| Cards | Grid 3 col desktop / 1 col móvil |
| Accordion | Sección FAQ |
| Modal | Ventana "Adoptar" en cada tarjeta |
| Form | Formulario de contacto con validación |

## Cómo usar

Abre `index.html` directamente en el navegador o súbelo a GitHub Pages / Netlify.
