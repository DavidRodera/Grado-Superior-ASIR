// ── Navbar scroll effect ──────────────────────────────────
window.addEventListener('scroll', () => {
  const nav = document.getElementById('mainNav');
  nav.classList.toggle('scrolled', window.scrollY > 50);
});

// ── Smooth scroll for anchor links ────────────────────────
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const offset = 75;
      const top = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});

// ── Filter cards ──────────────────────────────────────────
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', function () {
    document.querySelectorAll('.filter-btn').forEach(b => {
      b.classList.remove('active', 'btn-primary');
      b.classList.add('btn-outline-secondary');
    });
    this.classList.add('active', 'btn-primary');
    this.classList.remove('btn-outline-secondary');

    const filter = this.dataset.filter;
    document.querySelectorAll('.card-item').forEach(card => {
      if (filter === 'todos') {
        card.classList.remove('hidden');
      } else if (filter === 'cachorro' || filter === 'adulto') {
        card.classList.toggle('hidden', card.dataset.age !== filter);
      } else {
        card.classList.toggle('hidden', card.dataset.type !== filter);
      }
    });
  });
});

// ── Modal: update pet name ─────────────────────────────────
const modalEl = document.getElementById('modalAdopcion');
if (modalEl) {
  modalEl.addEventListener('show.bs.modal', event => {
    const btn = event.relatedTarget;
    const pet = btn.getAttribute('data-pet');
    document.getElementById('modalPetName').textContent = pet;
    const emojis = { Luna:'🐕', Mochi:'🐈', Nube:'🐇', Rocky:'🐩', Canela:'🐱', Thor:'🦮' };
    document.getElementById('modalPetEmoji').textContent = emojis[pet] || '🐾';
  });
}

// ── Form validation (Bootstrap 5 pattern) ─────────────────
const form = document.getElementById('formContacto');
if (form) {
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!form.checkValidity()) {
      form.classList.add('was-validated');
      return;
    }
    // Simulated success
    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Enviando...';
    setTimeout(() => {
      btn.innerHTML = '✅ ¡Solicitud enviada! Te contactamos en 24h';
      btn.classList.replace('btn-primary', 'btn-success');
      form.reset();
      form.classList.remove('was-validated');
    }, 1500);
  });
}
