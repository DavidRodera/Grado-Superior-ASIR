function Sumar(){
    let Numero1 = parseFloat(document.getElementById("idNum1").value);
    let Numero2 = parseFloat(document.getElementById("idNum2").value);
    let Resultado = Numero1 + Numero2;
    document.getElementById("idNumResultado").value = Resultado;
}

function Restar(){
    let Numero1 = parseFloat(document.getElementById("idNum1").value);
    let Numero2 = parseFloat(document.getElementById("idNum2").value);
    let Resultado = Numero1 - Numero2;
    document.getElementById("idNumResultado").value = Resultado;
}

function Producto(){
    let Numero1 = parseFloat(document.getElementById("idNum1").value);
    let Numero2 = parseFloat(document.getElementById("idNum2").value);
    let Resultado = Numero1 * Numero2;
    document.getElementById("idNumResultado").value = Resultado;
}

function Dividir(){
    let Numero1 = parseFloat(document.getElementById("idNum1").value);
    let Numero2 = parseFloat(document.getElementById("idNum2").value);
    if (Numero2 === 0){
        alert('No se puede dividir entre 0');
        document.getElementById("idNum1").value = "";
        document.getElementById("idNum2").value = "";
        document.getElementById("idNumResultado").value = "";
    }
    else {
        let Resultado = Numero1 / Numero2;
        document.getElementById("idNumResultado").value = Resultado;
    }
}

function Limpiar(){
    document.getElementById("idNum1").value = "";
    document.getElementById("idNum2").value = "";
    document.getElementById("idNumResultado").value = "";
}