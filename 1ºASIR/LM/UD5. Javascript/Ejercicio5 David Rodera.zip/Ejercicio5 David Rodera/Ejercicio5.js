let indiceActual = 0;

const btnArriba = document.getElementById('btnUp');
const btnAbajo = document.getElementById('btnDown');
const btnCalcular = document.getElementById('btnCalcular');
const numeroEntrada = document.getElementById('inputNumber');
const salidaResultado = document.getElementById('resultOutput');

function actualizarSeleccion() {
    document.getElementById("opt0").className = "option";
    document.getElementById("opt1").className = "option";
    document.getElementById("opt2").className = "option";
    document.getElementById("opt3").className = "option";

    let activo = "opt" + indiceActual;
    document.getElementById(activo).className = "option active";
}

function subirMenu() {
    if (indiceActual > 0) {
        indiceActual--;
        actualizarSeleccion();
    }
}

function bajarMenu() {
    if (indiceActual < 3) {
        indiceActual++;
        actualizarSeleccion();
    }
}

function ejecutarCalculo() {
    const num = parseFloat(numeroEntrada.value);
    
    if (isNaN(num) || num <= 0) {
        salidaResultado.value = "Error: El número debe ser >0";
        return;
    }

    let resultado = "";

    if (indiceActual === 0) {
        resultado = (num % 2 === 0) ? "SÍ es par" : "NO es par";
    } else if (indiceActual === 1) {
        resultado = (num % 2 !== 0) ? "SÍ es impar" : "NO es impar";
    } else if (indiceActual === 2) {
        resultado = esPrimo(num) ? "SÍ es primo" : "NO es primo";
    } else if (indiceActual === 3) {
        resultado = "Divisores: " + obtenerDivisores(num);
    }

    salidaResultado.value = resultado;
}

function esPrimo(n) {
    if (n <= 1) return false;
    for (let i = 2; i < n; i++) {
        if (n % i === 0) return false;
    }
    return true;
}

function obtenerDivisores(n) {
    let lista = [];
    for (let i = 1; i <= n; i++) {
        if (n % i === 0) lista.push(i);
    }
    return lista.join(", ");
}

btnArriba.onclick = subirMenu;
btnAbajo.onclick = bajarMenu;
btnCalcular.onclick = ejecutarCalculo;